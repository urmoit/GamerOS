# Implicit function declarations in user mode init functions

Created: January 30, 2026 7:54 PM
Type: Bug
Priority: P3
Status: Not Started