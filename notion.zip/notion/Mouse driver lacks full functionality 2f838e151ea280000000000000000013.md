# Mouse driver lacks full functionality

Created: January 31, 2026 9:53 PM
Type: Bug
Priority: P4
Status: Not Started

## Description

The mouse driver in `src/impl/drivers/mouse.c` lacks full functionality including cursor rendering, wheel support, acceleration, and multi-button support.

## Location

- File: `src/impl/drivers/mouse.c`
- Lines: 193-196

## Impact

- No mouse cursor rendering or visibility control
- No mouse wheel support or scroll events
- No mouse acceleration or sensitivity settings
- No support for multiple mouse buttons beyond left/middle/right

## Suggested Fix

Implement full mouse handling including cursor rendering, wheel event processing, and acceleration curves.

## Code Example (Current)

```c
// TODO: Implement mouse cursor rendering and visibility control
// TODO: Add mouse wheel support and scroll events
// TODO: Implement mouse acceleration and sensitivity settings
// TODO: Add support for multiple mouse buttons beyond left/middle/right
```
