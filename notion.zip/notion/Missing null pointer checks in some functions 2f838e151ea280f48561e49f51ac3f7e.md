# Missing null pointer checks in some functions

Created: January 30, 2026 7:53 PM
Type: Bug
Priority: P3
Status: Not Started