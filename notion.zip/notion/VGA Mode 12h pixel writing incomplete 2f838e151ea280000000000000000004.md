# VGA Mode 12h pixel writing incomplete

Created: January 31, 2026 9:52 PM
Type: Bug
Priority: P2
Status: Not Started

## Description

The VGA Mode 12h (640x480x16) pixel writing implementation in `src/impl/graphics/vga_graphics.c` may not work correctly due to planar mode complexity. The current implementation attempts to use write mode 2 but may not properly handle the planar memory organization.

## Location

- File: `src/impl/graphics/vga_graphics.c`
- Lines: 95-110

## Impact

- Mode 12h graphics may not display correctly
- Pixel operations may produce incorrect colors
- Screen may remain black or show garbage

## Suggested Fix

Verify planar pixel writing logic by testing on real hardware or QEMU with debug output. Consider using a working reference implementation for planar VGA modes.

## Code Example (Current)

```c
} else if (current_vga_mode == VGA_MODE_12H) {
    if (x >= 640 || y >= 480) return;
    uint32_t byte_offset = y * 80 + (x / 8);
    uint8_t bit_position = 7 - (x % 8);
    uint8_t pixel_mask = 1 << bit_position;
    uint8_t color_byte = (uint8_t)color & 0x0F;
    
    volatile uint8_t* fb = (volatile uint8_t*)0xA0000;
    outb(0x3CE, 0x05); outb(0x3CF, 0x02);
    outb(0x3CE, 0x08); outb(0x3CF, pixel_mask);
    outb(0x3C4, 0x02); outb(0x3C5, 0x0F);
    volatile uint8_t dummy = fb[byte_offset]; (void)dummy;
    fb[byte_offset] = color_byte;
    __asm__ volatile("mfence" ::: "memory");
}
```
