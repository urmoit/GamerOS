# Basic kernel (ELF64)

Created: January 30, 2026 7:17 PM
Type: Task
Priority: P1 🔥
Status: Completed
Depends on: GRUB Multiboot2 bootloader (GRUB%20Multiboot2%20bootloader%202f838e151ea2819795bfca150d1a5581.md)