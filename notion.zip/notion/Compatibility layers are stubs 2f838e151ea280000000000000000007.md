# Compatibility layers (MSDOS, Windows9x) are stubs

Created: January 31, 2026 9:53 PM
Type: Bug
Priority: P3
Status: Not Started

## Description

The compatibility layers for MSDOS and Windows 9x in `src/user_mode/compatibility_layers/` are stubs with TODO comments. They do not provide actual compatibility functionality.

## Location

- Files: `src/user_mode/compatibility_layers/msdos/msdos.c`, `src/user_mode/compatibility_layers/windows9x/windows9x.c`

## Impact

- No backward compatibility with DOS applications
- No backward compatibility with Windows 9x applications
- Cannot run legacy software

## Suggested Fix

Implement proper compatibility layer functionality including system call translation, memory management, and API emulation.

## Code Example (Current)

```c
int msdos_translate_syscall(uint32_t syscall_num, void* params) {
    // TODO: Translate MS-DOS syscall to native
    // For now, return failure
    return -1;
}
```
