# Color value overflow in GUI functions (32-bit to 8-bit conversion)

Created: January 30, 2026 7:54 PM
Type: Bug
Priority: P3
Status: Not Started