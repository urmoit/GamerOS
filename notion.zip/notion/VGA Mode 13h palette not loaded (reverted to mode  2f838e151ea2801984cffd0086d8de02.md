# VGA Mode 13h palette not loaded (reverted to mode 12h testing)

Created: January 30, 2026 7:53 PM
Type: Bug
Priority: P2
Status: In Progress