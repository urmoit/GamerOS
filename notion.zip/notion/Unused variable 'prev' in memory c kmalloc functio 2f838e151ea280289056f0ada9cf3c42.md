# Unused variable 'prev' in memory.c kmalloc function

Created: January 30, 2026 7:54 PM
Type: Bug
Priority: P3
Status: Not Started