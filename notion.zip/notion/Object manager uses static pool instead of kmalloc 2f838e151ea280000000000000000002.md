# Object manager uses static pool instead of kmalloc

Created: January 31, 2026 9:52 PM
Type: Bug
Priority: P2
Status: Not Started

## Description

The object manager in `src/executive/object_manager/object_manager.c` uses a static 4096-byte pool for all kernel objects instead of using the dynamic memory allocator (kmalloc/kfree). This severely limits the number of objects that can be created.

## Location

- File: `src/executive/object_manager/object_manager.c`
- Lines: 80-89

## Impact

- Limited to 4096 bytes total for all kernel objects
- Cannot create more than a few objects before running out of memory
- Wastes memory if objects are not used
- No dynamic growth capability

## Suggested Fix

Replace the static pool with kmalloc/kfree calls for dynamic object allocation.

## Code Example (Current)

```c
static uint8_t object_pool[4096];
static uint32_t pool_offset = 0;

if (pool_offset + size > 4096) {
    return INVALID_HANDLE;
}
obj = (object_t*)(object_pool + pool_offset);
pool_offset += size;
```

## Code Example (Fixed)

```c
obj = (object_t*)kmalloc(size);
if (!obj) {
    return INVALID_HANDLE;
}
```
