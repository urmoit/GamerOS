# Font rendering uses simple rectangles instead of bitmap font

Created: January 31, 2026 9:53 PM
Type: Bug
Priority: P4
Status: Not Started

## Description

The UI system in `src/impl/ui_system/ui.c` uses simple rectangle drawing to render characters instead of using the proper bitmap font from `font.c`. This limits character support and produces poor text quality.

## Location

- File: `src/impl/ui_system/ui.c`
- Lines: 12-94

## Impact

- Limited character support (only H, O, M, E, F, I, L, S, T, N, G, A, R)
- Poor text quality
- No support for numbers or special characters
- Inconsistent text rendering

## Suggested Fix

Use the bitmap font from `font.c` instead of rectangle drawing for character rendering.

## Code Example (Current)

```c
static void draw_char(uint32_t x, uint32_t y, char c, uint8_t color) {
    switch (c) {
        case 'H': case 'h':
            vga_fill_rect(x + 1, y, 1, char_height, color);
            vga_fill_rect(x + 4, y, 1, char_height, color);
            vga_fill_rect(x + 1, y + 3, 4, 1, color);
            break;
        // ... limited character support
    }
}
```

## Code Example (Fixed)

```c
static void draw_char(uint32_t x, uint32_t y, char c, uint8_t color) {
    vga_draw_char(x, y, c, color); // Use proper bitmap font
}
```
