# Hard-coded memory mapping only 4MB in paging.c

Created: January 31, 2026 9:53 PM
Type: Bug
Priority: P2
Status: Not Started

## Description

The paging setup in `src/impl/kernel_mode/hal/memory/paging.c` only maps the first 4MB of memory using hard-coded addresses. This limits the system to 4MB of usable memory and may cause issues if the kernel or applications need more memory.

## Location

- File: `src/impl/kernel_mode/hal/memory/paging.c`
- Lines: 20-31

## Impact

- System limited to 4MB of mapped memory
- VGA buffer relies on being in first 2MB
- No support for high memory or extended memory
- Cannot use more than 4MB of physical RAM

## Suggested Fix

Implement dynamic memory mapping for larger address spaces, or at least map more memory at boot time using a loop to set up additional page tables.

## Code Example (Current)

```c
// Identity map first 4MB (2 pages) to ensure kernel has enough mapped memory
p4_table[0] = (uint64_t)&p3_table | 0b11;
p3_table[0] = (uint64_t)&p2_table | 0b11;
p2_table[0] = 0x0 | 0b10000011;      // 0-2MB
p2_table[1] = 0x200000 | 0b10000011; // 2-4MB
```
