# GUI app uses hardcoded direct framebuffer access instead of proper graphics API

Created: January 31, 2026 9:52 PM
Type: Bug
Priority: P2
Status: Not Started

## Description

The GUI application in `src/impl/gui_app.c` directly accesses the VGA framebuffer at address 0xA0000 instead of using the proper graphics API functions like `vga_fill_rect()`. This bypasses the graphics abstraction layer and hardcodes the application to 320x200 mode only.

## Location

- File: `src/impl/gui_app.c`
- Lines: 260-291

## Impact

- Code is not portable to other graphics modes
- Bypasses graphics abstraction layer
- Hardcoded for 320x200 mode only
- Will not work with VESA modes or Mode 12h

## Suggested Fix

Replace direct framebuffer access with calls to `vga_fill_rect()` and other graphics API functions that respect the current video mode.

## Code Example (Current)

```c
volatile uint8_t* fb = (volatile uint8_t*)0xA0000;
for (uint32_t y = 0; y < 50; y++) {
    for (uint32_t x = 0; x < 320; x++) {
        fb[y * 320 + x] = 0x0F; // White
    }
}
```

## Code Example (Fixed)

```c
vga_fill_rect(0, 0, 320, 50, 0x0F); // White bar
```
