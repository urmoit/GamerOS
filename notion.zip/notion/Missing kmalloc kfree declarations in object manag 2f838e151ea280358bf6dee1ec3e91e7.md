# Missing kmalloc/kfree declarations in object manager

Created: January 30, 2026 7:54 PM
Type: Bug
Priority: P3
Status: Not Started