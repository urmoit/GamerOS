# Theme colors use 32-bit values but VGA mode 13h only supports 8-bit palette

Created: January 30, 2026 7:55 PM
Type: Bug
Priority: P4
Status: In Progress