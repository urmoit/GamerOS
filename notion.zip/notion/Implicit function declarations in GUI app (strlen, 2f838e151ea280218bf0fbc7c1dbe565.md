# Implicit function declarations in GUI app (strlen, workstation_create_desktop)

Created: January 30, 2026 7:53 PM
Type: Bug
Priority: P3
Status: Not Started