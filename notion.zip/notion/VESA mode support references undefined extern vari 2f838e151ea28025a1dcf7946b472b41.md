# VESA mode support references undefined extern variable 'vesa_success’

Created: January 30, 2026 7:54 PM
Type: Bug
Priority: P3
Status: Testing