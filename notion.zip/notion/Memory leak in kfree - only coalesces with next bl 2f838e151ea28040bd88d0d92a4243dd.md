# Memory leak in kfree - only coalesces with next block, not previous block

Created: January 30, 2026 7:54 PM
Type: Bug
Priority: P3
Status: Not Started